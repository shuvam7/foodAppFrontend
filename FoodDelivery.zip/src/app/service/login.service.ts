import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { JwtResponse } from '../model/jwt-response';



@Injectable({
  providedIn: 'root'
})
export class LoginService 
{

  constructor(private http: HttpClient) {}
  login(data): Observable<any> {
 
    
  return this.http.post<any>("http://localhost:8888/user/login", data );

}
}