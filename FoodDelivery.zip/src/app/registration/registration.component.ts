import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { Registration } from '../model/registration';
import { Router } from '@angular/router';
import { AuthService } from '../authorization/auth.service';
 import {TokenStorageService} from '../service/token-storage.service';
 import { SignupService } from '../service/signup.service';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  signupForm: FormGroup;
  submitted: boolean;
  signup:Registration;
  type: string = "";
  title = 'Signup';
  isLoggedIn: boolean = false;
  isLoginFailed: boolean = false;
  errorMessage: string = '';
  roles: string[] = [];
  constructor(private formBuilder: FormBuilder,private tokenStorage:TokenStorageService,private ls:SignupService, private router: Router,private auth: AuthService) { }

  ngOnInit() {
    this.submitted = false;
    this.signupForm = this.formBuilder.group({
      "userName": ['', [Validators.required, Validators.minLength(3), Validators.maxLength(10)]],
      "userEmail": ['', [Validators.email]],
      "password": ['', [Validators.required, Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#$%^&*]).{8,}$')]]
    })


  }
 get f() { return this.signupForm.controls; }


 onSubmit() {
  this.submitted = true;
  if (this.signupForm.invalid) {
    console.log(this.signupForm.controls);
    return;
  };
  
    this.router.navigate(["login"]);
  this.ls.signup(this.signup).subscribe(
    data => {
      console.log(data);
    
    },
    error => {
      console.log("Use other details");
      this.errorMessage = JSON.stringify(error.error);
      console.log(this.errorMessage );

    }
  );
}
}
