export class Registration{
    id:number;
    username : string;
    emailId : String;
    password :string;


constructor(){
//    this.id=id;
//     this.username=username;
//     this.emailId=emailId;
//     this.password=password;
}

}