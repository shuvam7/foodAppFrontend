import { Component, OnInit } from '@angular/core';
import { HostListener } from "@angular/core";
import { HomelistService } from '../service/homelist.service';
import { Cart } from '../model/cart';
import { Food } from '../model/food';
import { AuthService } from '../authorization/auth.service';
import { Registration } from '../model/Registration';

@Component({
  selector: 'app-homelist',
  templateUrl: './homelist.component.html',
  styleUrls: ['./homelist.component.css']
})
export class HomelistComponent implements OnInit {
  isShow: boolean;
  cartStatus: boolean = false;
  alert: boolean = false;
  itemList: boolean;
  listNull: boolean;
  screenHeight: any;
  screenWidth: any;
  message: any;
  alerttype: any;
  totalCost: number = 0;
  foodList: Array<any>;
  errorMessage: string = '';
  food: Food;
  cart: Cart;
  user = new Registration();
  foodCart: Array<any> = new Array();
  constructor(private listService: HomelistService, private auth: AuthService) {
    this.isShow = false;
    this.itemList = true;

  }

  ngOnInit() {
    this.getScreenSize();
    this.listService.getAll().subscribe(data => {
      this.foodList = data;

      if (this.foodList == null) {
        this.listNull = false;
      }
    });
    this.user.id = Number(localStorage.getItem('userId'));
    this.listService.getCart(this.user).subscribe(data => {
      this.foodCart = data;


    });
  }

  @HostListener('window:resize', ['$event'])
  getScreenSize(event?) {
    this.screenHeight = window.innerHeight;
    this.screenWidth = window.innerWidth;
  }
  sub(item, no) {
    let noOfOrder = item.noOfQty;
    this.listService.getCart(this.user).subscribe(data => {
      this.foodCart = data;
      if (noOfOrder > 0) {
        noOfOrder--;
        this.foodCart[no].noOfQty = noOfOrder;

        this.listService.updateCart(this.foodCart[no]).subscribe(data => {
          this.foodCart = data;
          for (var i = 0; i < this.foodCart.length; i++) {
            if (this.foodCart[i].noOfQty > 0) {
              this.foodCart[i].itemTotalPrice = this.foodCart[i].noOfQty * this.foodCart[i].food.price;
            }
          }
          this.calculateCost(this.foodCart[no].food.price, "sub");
        });

      }
    });
  }
  add(item, no) {
    let noOfOrder = item.noOfQty;
    this.listService.getCart(this.user).subscribe(data => {
      this.foodCart = data;
      if (noOfOrder < 10) {
        noOfOrder++;
        this.foodCart[no].noOfQty = noOfOrder;

        this.listService.updateCart(this.foodCart[no]).subscribe(data => {
          this.foodCart = data;

          for (var i = 0; i < this.foodCart.length; i++) {
            if (this.foodCart[i].noOfQty > 0) {
              this.foodCart[i].itemTotalPrice = this.foodCart[i].noOfQty * this.foodCart[i].food.price;
            }
          }
          this.calculateCost(this.foodCart[no].food.price, "add");
        });

      }
    });

  }
  addToCart(cartAddItem) {
    this.cartStatus = false;
    console.log(this.foodCart);
    for (var i = 0; i < this.foodCart.length; i++) {
      if (this.foodCart[i].food.id == cartAddItem.id) {
        this.cartStatus = true;
        this.message = "Already added to cart...";
        this.alerttype = "alert-warning";
        this.alert = true;
        setTimeout(function () {
          this.alert = false;
        }.bind(this), 3000);
        break;
      }
    }
    if (this.cartStatus == false) {
      this.food = new Food(
        cartAddItem.id, cartAddItem.name, cartAddItem.price, cartAddItem.quantity, cartAddItem.description, cartAddItem.rating, cartAddItem.filename, cartAddItem.path);
      this.cart = new Cart(null, this.food, this.user);
      this.listService.cartAdd(this.cart).subscribe(
        data => {
          this.listService.getCart(this.user).subscribe(data => {
            this.foodCart = data;
            this.message = "Successfully added to cart...";
            this.alerttype = "alert-success";
            this.alert = true;
            setTimeout(function () {
              this.alert = false;
            }.bind(this), 3000);
            if (this.foodList == null) {
              this.listNull = false;
            }
          });

        },
        error => {
          console.log("Use other details");
          this.errorMessage = JSON.stringify(error.error);
          console.log(this.errorMessage);

        }
      )
    }
  }

  toggleCart() {
    if (this.isShow == false) {
      this.listService.getCart(this.user).subscribe(data => {
        this.foodCart = data;
        for (var i = 0; i < this.foodCart.length; i++) {
          if (this.foodCart[i].noOfQty > 0) {
            this.foodCart[i].itemTotalPrice = this.foodCart[i].noOfQty * this.foodCart[i].food.price;
            this.calculateCost(this.foodCart[i].itemTotalPrice, "add");
          }
        }
        if (this.foodList == null) {
          this.listNull = false;
        }
      });
      this.isShow = true;
    }
    else
      this.isShow = false;

    if (this.screenWidth <= 1000 && this.isShow == true)
      this.itemList = false;
    else if (this.screenWidth <= 1000 && this.isShow == false)
      this.itemList = true;

  }
  calculateCost(totalPrice, type) {
    if (type == "add") {
      this.totalCost = totalPrice + this.totalCost;
      console.log(type);
    }
    else if (type == "sub") {
      this.totalCost = this.totalCost - totalPrice;
      console.log(type);
    }
  }
  removeItem(id, index) {
    if (this.totalCost > 0)
      this.totalCost = this.totalCost - this.foodCart[index].itemTotalPrice;
    this.cart = new Cart(id, null, null);
    this.listService.deleteItem(this.cart).subscribe(
      data => {
        this.foodCart.splice(index, 1);
        this.message = "Item removed...";
        this.alerttype = "alert-success";
        this.alert = true;
        setTimeout(function () {
          this.alert = false;
        }.bind(this), 3000);
      },
      error => {
        this.errorMessage = JSON.stringify(error.error);
        console.log(this.errorMessage);

      }
    )
  }
}
