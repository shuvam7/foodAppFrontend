import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { Routes, RouterModule } from '@angular/router';
import { NavbarComponent } from './navbar/navbar.component';
import { LoginComponent } from '../app/modules/authorization/login/login.component';
import { HomeimgComponent } from '../app/modules/food-delivery/homeimg/homeimg.component';
import{ReactiveFormsModule, FormsModule} from '@angular/forms';
import{HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { AuthGuard } from './authguard/auth.guard';
import { AuthorizationModule} from '../app/modules/authorization/authorization.module';
import { FoodDeliveryModule} from '../app/modules/food-delivery/food-delivery.module';
import { HomelistComponent } from './modules/food-delivery/homelist/homelist.component';
import { TokenInterceptorService } from './modules/food-delivery/token-interceptor';
RouterModule.forRoot(
  [
    { path: "", component: LoginComponent,pathMatch: 'full'}
  ]
)
@NgModule({
  declarations: [
    AppComponent,  
    NavbarComponent,
    HomeimgComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AuthorizationModule,
    FoodDeliveryModule,
    RouterModule
  ],
  providers: [AuthGuard,HomelistComponent,

    {
 
     provide: HTTP_INTERCEPTORS,
 
     useClass: TokenInterceptorService,
 
     multi: true
 
    }
 
   ],
  bootstrap: [AppComponent]
})
export class AppModule { }
