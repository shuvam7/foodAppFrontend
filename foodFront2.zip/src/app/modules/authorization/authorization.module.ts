import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component'; 
import{ReactiveFormsModule, FormsModule} from '@angular/forms';
import { AuthService } from './auth.service';
const routes: Routes = [

  { path:'login',component: LoginComponent },
  { path:'signup',component:RegistrationComponent },
 { path: '',redirectTo:'/login', pathMatch:'full' },
  
];
@NgModule({
  declarations: [LoginComponent,RegistrationComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [AuthService],
  exports: [
    RouterModule
  ]

})
export class AuthorizationModule { }
