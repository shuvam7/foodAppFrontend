import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { Registration } from '../../model/registration';
import { Router } from '@angular/router';

// import {TokenStorageService} from '../service/token-storage.service';
 import { AuthService } from '../auth.service';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  signupForm: FormGroup;
  submitted: boolean;
  signup = new Registration();
  type: string = "";
  title = 'Signup';
  isLoggedIn: boolean = false;
  isLoginFailed: boolean = false;
  errorMessage: string = '';
  roles: string[] = [];
  constructor(private formBuilder: FormBuilder,private ls:AuthService, private router: Router,private auth: AuthService) { }

  ngOnInit() {
    this.submitted = false;
    this.signupForm = this.formBuilder.group({
      "userName": ['', [Validators.required, Validators.minLength(3), Validators.maxLength(10)]],
      "userEmail": ['', [Validators.email]],
      "password": ['', [Validators.required, Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#$%^&*]).{8,}$')]]
    })


  }
 get f() { return this.signupForm.controls; }


 onSubmit() {
  this.submitted = true;
  if (this.signupForm.invalid) {
    return;
  };
  this.ls.signup(this.signup).subscribe(
    data => {
      this.router.navigate(["login"]);
    },
    error => {
      console.log(error);
      this.errorMessage = JSON.stringify(error);
      console.log(this.errorMessage );

    }
  );
}
}
