import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AuthService } from './auth.service';
import { HttpClientModule } from '@angular/common/http';
import { TestBed, inject, fakeAsync } from '@angular/core/testing';
import{ReactiveFormsModule, FormsModule} from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
const testConfig= {
  userData: {
    emailId: 'testEmail',
    username: 'testUsername',
    password: 'testPassword'
  },

  loginUser: {
      positive: {
          emailId: 'testEmail',
          password: 'testPass'
      }
  }
}

fdescribe('AuthService', () => {
  let authService: AuthService;

  beforeEach(() =>{
     TestBed.configureTestingModule({
      imports: [HttpClientModule,HttpClientTestingModule,ReactiveFormsModule,FormsModule,RouterTestingModule],
      providers: [AuthService]

     });
     authService=TestBed.get(AuthService);
    });

  it('should be created authenticate service', () => {
    inject([AuthService], (service: AuthService) => {
      expect(service).toBeTruthy();
  
  });
});
it('should register user data', fakeAsync(() => {
  let data = testConfig.userData;
  inject([AuthService, HttpTestingController], (backend: HttpTestingController) => {
    const mockReq = backend.expectOne(authService.authServiceEndpoint);
    expect(mockReq.request.url).toEqual(authService.authServiceEndpoint, 'request url should match with json server api url');
    expect(mockReq.request.method).toBe('POST', 'Should handle requested method type');
    mockReq.flush(data);
    backend.verify();
  });
  authService.signup(data).subscribe((res: any) => {
    expect(res).toBeDefined();
    expect(res._body).toBe(data, 'data should be same');
  });
}));

it('should login user', fakeAsync(() => {
  let userData = testConfig.loginUser.positive;
  inject([AuthService, HttpTestingController], (backend: HttpTestingController) => {
    const mockReq = backend.expectOne(authService.authServiceEndpoint);
    expect(mockReq.request.url).toEqual(authService.authServiceEndpoint, 'request url should match with json server api url');
    expect(mockReq.request.method).toBe('POST', 'Should handle requested method type');
    mockReq.flush(userData);
    backend.verify();
  });
  authService.login(userData).subscribe((res: any) => {
    expect(res).toBeDefined();
    expect(res._body).toBe(userData, 'data should be same');
  });
}));
});
