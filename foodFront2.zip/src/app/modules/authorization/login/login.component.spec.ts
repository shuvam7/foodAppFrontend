import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginComponent } from './login.component';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

import { Location } from '@angular/common';
import { of } from 'rxjs';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';


const testConfig= {
  userData: {
    emailId: 'testEmail',
    username: 'testUsername',
    password: 'testPassword'
  }
}

fdescribe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let authservice:AuthService;
  let spyUser:any;
  let routes:Router;
  let location:Location;

  class AuthServiceStub{
    currentUser:any;

    constructor(){

    }
    login(credentials) {
      if(credentials.userName==testConfig.userData.username)
      {
        console.log(this.currentUser);
        return of(credentials.userName)
      }
      else{
        return of(false);
      }
    }
  }
  class dummy {

  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      imports:[FormsModule,HttpClientModule,ReactiveFormsModule,FormsModule,RouterTestingModule.withRoutes([{path: '', component: dummy}])],
      providers:[{provide:AuthService,useClass:AuthServiceStub}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    routes = TestBed.get(Router);
    location = TestBed.get(Location);
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    fixture.debugElement.injector.get(AuthService);
  });

  it('should create app component',async( () => {
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));

  it('should contain two input box for username and password', () => {
    let userName=fixture.debugElement.query(By.css('#email'));
    let password = fixture.debugElement.query(By.css('#password'));
    let userButton = fixture.debugElement.query(By.css('#loginButton'));
    let userNameInput=userName.nativeElement;
    let passwordInput = password.nativeElement;
    let userButtonInput = userButton.nativeElement;
    expect(userNameInput).toBeTruthy();
    expect(passwordInput).toBeTruthy();
    expect(userButtonInput).toBeTruthy();
  });

  it('should redirect to login if registered successfully', async(() => {
   let userName = fixture.debugElement.query(By.css('#email'));
    let password = fixture.debugElement.query(By.css('#password'));
    let userButton = fixture.debugElement.query(By.css('#loginButton'));

  let userIdInput = userName.nativeElement;
    let passwordInput = password.nativeElement;
    let userButtonInput = userButton.nativeElement;
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      userIdInput.value = 'testuser';
      passwordInput.value = 'testpass';
      userIdInput.dispatchEvent(new Event('inptut'));
      passwordInput.dispatchEvent(new Event('inptut'));
      userButtonInput.click();
    }).then(() => {
      expect(location.path()).toBe('');
    });
  }));
  })
