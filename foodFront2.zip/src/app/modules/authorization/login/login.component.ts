

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { Registration } from '../../model/registration';
import { Router } from '@angular/router';
//import { AuthService } from '../authorization/auth.service';
// import {TokenStorageService} from '../service/token-storage.service';
 import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted: boolean;
  login=new Registration();
  type: string = "";


  title = 'Login';
  isLoggedIn: boolean = false;
  isLoginFailed: boolean = false;
  errorMessage: string = '';
  roles: string[] = [];

  constructor(private formBuilder: FormBuilder,private ls:AuthService, private router: Router,private auth: AuthService) {

  }

  ngOnInit() {
  //   if (this.auth.isLoggedIn()) {
  //     this.router.navigate(['list']);
  //  }
    this.submitted = false;
    this.loginForm = this.formBuilder.group({
      "userEmail": ['', [Validators.email]],
      "password": ['', [Validators.required, Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#$%^&*]).{8,}$')]]
    })
    // if (this.tokenStorage.getToken()) {
    // this.isLoggedIn = true;
    //   this.roles = this.tokenStorage.getAuthorities();
    //  }
  }
  get f() { return this.loginForm.controls; }

  hello() {
    alert("hi");
  }
  onSubmit() {
    this.submitted = true;

    if (this.loginForm.invalid) {
      return;
    };
    this.ls.login(this.login).subscribe(
      data => {
        let message=JSON.stringify(data.message)
        console.log("Login successful",message);
        if(data['token']) {
          this.auth.sendToken(data['token']);
          this.router.navigate(['/list']);
        }
        
      },
      error => {
  
        
        this.errorMessage = JSON.stringify(error.error);

        if(error.status=='400'){
          alert(this.errorMessage);
          this.router.navigate(['']);
        }
        else if (error.status=='403'){

          alert(this.errorMessage);
          this.router.navigate(['']);
        }

      }
    );
  }

}
