import {Food} from './food';
import { Registration } from './registration';
export class Cart{
    id:number;
    food:Food;
    user:Registration;
constructor(id:number,food: Food,user:Registration){
    this.id=id;
    this.food=food;
    this.user=user;
}
}