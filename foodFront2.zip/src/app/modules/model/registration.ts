export class Registration{
    id:number;
    username : string;
    emailId : string;
    password :string;

    

}