import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
//import { HomeimgComponent } from './homeimg/homeimg.component';
import { HomelistComponent } from './homelist/homelist.component';
import { AuthGuard } from '../../authguard/auth.guard';
import {AuthorizationModule} from '../authorization/authorization.module';
import{ReactiveFormsModule, FormsModule} from '@angular/forms';
import { FoodDeliveryService } from './food-delivery.service';
const routes: Routes = [
  { path: 'list', component: HomelistComponent,canActivate:  [AuthGuard] }, 
];
@NgModule({
  declarations: [HomelistComponent],
  imports: [
    CommonModule,
    AuthorizationModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [FoodDeliveryService]
})
export class FoodDeliveryModule { }
