import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeimg',
  templateUrl: './homeimg.component.html',
  styleUrls: ['./homeimg.component.css']
})
export class HomeimgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
