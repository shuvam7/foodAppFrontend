import { TestBed } from '@angular/core/testing';

import { FoodDeliveryService } from './food-delivery.service';

describe('FoodDeliveryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FoodDeliveryService = TestBed.get(FoodDeliveryService);
    expect(service).toBeTruthy();
  });
});
