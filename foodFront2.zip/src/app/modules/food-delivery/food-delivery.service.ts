
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class FoodDeliveryService {
  authServiceEndpoint:string = "http://localhost:8888/api/v1";
  token:string;
  constructor(private http: HttpClient) {
  }

  cartAdd(data): Observable<any> {
    return this.http.post(`${this.authServiceEndpoint}/cart/add`,data);
  }
  getAll(): Observable<any> {
    return this.http.get(`${this.authServiceEndpoint}/food/list`);
  }
  getCart(data): Observable<any> {
    return this.http.post(`${this.authServiceEndpoint}/cart/list`,data);
  }
  deleteItem(data): Observable<any> {
    return this.http.post(`${this.authServiceEndpoint}/cart/delete`,data);
  }
  updateCart(data): Observable<any> {
    return this.http.post(`${this.authServiceEndpoint}/cart/update`,data);
  }
  placeOrder(data): Observable<any> {
    return this.http.post(`${this.authServiceEndpoint}/cart/order`,data);
  }
}
