export class Registration{
    id:number;
    username : string;
    emailId : String;
    password :string;


constructor(id:number,username:string,emailId:string,password:string){
   this.id=id;
    this.username=username;
    this.emailId=emailId;
    this.password=password;
}

}