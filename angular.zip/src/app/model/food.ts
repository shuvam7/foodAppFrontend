

export class Food {
    id: number;
    name: string;
    price: number;
    quantity: number;
    filename: string;
    rating: number;
    description: string;
    path:string;

    constructor(id:number,  name: string,
        price: number,
        quantity: number,
        description: string,
        rating: number,
        filename: string,
        path: string
        ) {


        this.id = id;
        this.name=name;
        this.quantity = quantity;
        this.description=description;
        this.price=price;
        this.filename=filename;
        this.rating=rating;
        this.path=path;
    }
}