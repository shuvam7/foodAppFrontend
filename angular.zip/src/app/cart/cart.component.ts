import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
isShow:boolean;
  constructor() { }

  ngOnInit() {
  }
  toggleCart(){
    if(this.isShow==false){
    this.isShow=true;
    }
    else{
      this.isShow=false; 
    }
    
  }
}
