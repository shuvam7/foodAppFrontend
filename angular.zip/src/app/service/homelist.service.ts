import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class HomelistService {
  
  constructor(private http: HttpClient) {
  }

  cartAdd(data): Observable<any> {
    return this.http.post('http://localhost:8888/cart/add',data);
  }
  getAll(): Observable<any> {
    return this.http.get('http://localhost:8888/food/list');
  }
  getCart(data): Observable<any> {
    return this.http.post('http://localhost:8888/cart/list',data);
  }
  deleteItem(data): Observable<any> {
    return this.http.post('http://localhost:8888/cart/delete',data);
  }
  updateCart(data): Observable<any> {
    return this.http.post('http://localhost:8888/cart/update',data);
  }
}
