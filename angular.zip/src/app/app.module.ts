import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { NavbarComponent } from './navbar/navbar.component';
import { CartComponent } from './cart/cart.component';
import { HomeimgComponent } from './homeimg/homeimg.component';
import { HomelistComponent } from './homelist/homelist.component';
import{ReactiveFormsModule, FormsModule} from '@angular/forms';
import { RegistrationComponent } from './registration/registration.component'; 
import{HttpClientModule} from '@angular/common/http';
import { AuthService } from './authorization/auth.service';
import { AuthGuard } from './authorization/auth.guard';

const routes: Routes = [

  { path:'login',component: LoginComponent },
  { path:'signup',component:RegistrationComponent },
  { path: 'list', component: HomelistComponent,canActivate:  [AuthGuard] },
 { path: '',redirectTo:'/login', pathMatch:'full' },
  
];
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    NavbarComponent,
    CartComponent,
    HomeimgComponent,
    HomelistComponent,
    RegistrationComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [LoginComponent,AuthService,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
